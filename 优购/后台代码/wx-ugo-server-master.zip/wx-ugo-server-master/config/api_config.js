const config = {
  api_host:"https://www.zhengzhicheng.cn/"
}

module.exports = config
