const path = require('path')
module.exports = {
    AppID: "wxfb52f2d7b2f6123a",
    AppSecret: "64f4fa1a57f5b0890cb6042532e5ad58",
    MchId: "1500880121",
    PayKey: "f5c8e398d51c6261da35f2c246505c99",
    wxPayNotifiyUrl: "http://47.112.97.255/orders/notifiy"
}