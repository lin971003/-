function sayHello(){
  wx.showToast({
    title: '今天天气不错哦~',
  })
}

module.exports = sayHello