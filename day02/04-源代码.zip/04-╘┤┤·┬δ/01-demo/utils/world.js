export default function print() {
  wx.showToast({
    title: '如果人人人都献出一点爱',
  })
}